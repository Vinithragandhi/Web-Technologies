package classes;

import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Coordinates {

	double latitude;
	double longitude;
	
	
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude1) {
		DecimalFormat df = new DecimalFormat("#.##");
		df.setRoundingMode(RoundingMode.HALF_UP);
		    latitude = new Double(df.format(latitude1));

	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude1) {
		DecimalFormat df = new DecimalFormat("#.##");
		df.setRoundingMode(RoundingMode.HALF_UP);
		    longitude = new Double(df.format(longitude1));
	}
}
