package actions;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import actions.SentimentAction;
import classes.Coordinates;
import classes.DandelionResponse;
import classes.Tweets;
import twitter4j.GeoLocation;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.Query.Unit;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterAction {
	Twitter twitter;
	public Twitter getTwitter() {
		return twitter;
	}
	public void setTwitter(Twitter twitter) {
		this.twitter = twitter;
	}
	
	
	public TwitterAction() {
		//authenticating via the Twitter OAuth
		ConfigurationBuilder cf = new ConfigurationBuilder();
		cf.setDebugEnabled(true)
		.setOAuthConsumerKey("hfhB3nGW15U007g2o02bQJYfK")
		.setOAuthConsumerSecret("l0zLCEFsU81maMPlMYUCGVJlFMuJzUdMDa1T1YVXNowuQtwxZ8")
		.setOAuthAccessToken("831932687799693313-f7R1rnZUvWWOKJ5qrlTYszSBFALU5HB")
		.setOAuthAccessTokenSecret("tO7Eg1CITULt5G43ztqkQm01XHpFOvNCngBz8hTf5YKya");
		TwitterFactory tf = new TwitterFactory(cf.build());
		twitter = tf.getInstance(); //twitter instance which is used to send requests
	}
public List<Tweets> getTweets(String topic){
	SentimentAction sentiment = new SentimentAction();
	List<Tweets> tweetList =null;
	String tweet = null;
	String encodedTweet = null;
	DandelionResponse response = null;
	try {
			tweetList = new ArrayList<Tweets>();
		if(topic != null){					
			Query query = new Query();
			QueryResult result = twitter.search(new Query(topic));
			if(result != null){
				List<Status> tweets = result.getTweets();
				Tweets tweetObj = null;
				for(Status status : tweets){
					tweetObj = new Tweets();
					tweetObj.setTweet(status.getText());
					tweetList.add(tweetObj);
				}
			}
		}
	} catch (TwitterException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return tweetList;
}
public List<Tweets> getTweetsWithLocation(String topic,String location){
	BingMapsAction bingAction = new BingMapsAction();
	Coordinates coordinatesObj = new Coordinates();
	List<Tweets> tweetList =null;
	String encodedTweet = null;
	try {
		coordinatesObj = bingAction.getCoordinates(location);
			tweetList = new ArrayList<Tweets>();
		if(topic != null){					
			Query query = new Query();
			GeoLocation coordinates = new GeoLocation(coordinatesObj.getLatitude(), coordinatesObj.getLongitude());
			System.out.println(coordinates.getLatitude()+"long:"+coordinates.getLongitude()+"latlong");
			Unit unit = Unit.mi;
			query.setQuery(topic);
			query.setGeoCode(coordinates, 500, unit);//setting query object with required values
			QueryResult result = twitter.search(query); //request is sent
			//response is extracted in the list object
			if(result != null){
				List<Status> tweets = result.getTweets();
				Tweets tweetObj = null;
				for(Status status : tweets){
					tweetObj = new Tweets();
					tweetObj.setTweet(status.getText());
					tweetObj.setUsername(status.getUser().getName());
					tweetList.add(tweetObj);
				}
			}
		}
	} catch (TwitterException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return tweetList;
}
}
