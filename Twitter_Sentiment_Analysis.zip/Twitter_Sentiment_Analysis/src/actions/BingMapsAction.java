package actions;

import java.util.List;

import javax.xml.bind.JAXBElement;

import classes.Coordinates;
import net.virtualearth.dev.webservices.v1.common.ArrayOfGeocodeLocation;
import net.virtualearth.dev.webservices.v1.common.ArrayOfGeocodeResult;
import net.virtualearth.dev.webservices.v1.common.Credentials;
import net.virtualearth.dev.webservices.v1.common.GeocodeLocation;
import net.virtualearth.dev.webservices.v1.common.GeocodeResult;
import net.virtualearth.dev.webservices.v1.common.ObjectFactory;
import net.virtualearth.dev.webservices.v1.geocode.GeocodeRequest;
import net.virtualearth.dev.webservices.v1.geocode.GeocodeResponse;
import net.virtualearth.dev.webservices.v1.geocode.GeocodeService;
import net.virtualearth.dev.webservices.v1.geocode.IGeocodeService;
import net.virtualearth.dev.webservices.v1.geocode.IGeocodeServiceGeocodeResponseSummaryFaultFaultMessage;

public class BingMapsAction {
public Coordinates getCoordinates(String location){
	Coordinates coordinates = new Coordinates();
	GeocodeRequest reqObj = new GeocodeRequest();
	ObjectFactory comObj = new ObjectFactory();
	net.virtualearth.dev.webservices.v1.geocode.ObjectFactory geoObj = new net.virtualearth.dev.webservices.v1.geocode.ObjectFactory();
	Credentials credObj = new Credentials();
	JAXBElement<String> appId = comObj.createCredentialsApplicationId("AlqXDDDxQjwQR1MzP3tm7gK51JqCVMUYhpGPkmeLs22s3SeIhHvR58VRBQE6OLlk");
	credObj.setApplicationId(appId); // credential object created for authentication

	JAXBElement<String> query = geoObj.createGeocodeRequestQuery(location);
	
	JAXBElement<Credentials> cred = comObj.createCredentials(credObj);
	reqObj.setQuery(query);// query set according to user input
	reqObj.setCredentials(cred);//request object set with credentials
	GeocodeService service = new GeocodeService();
	IGeocodeService serviceObj = service.getBasicHttpBindingIGeocodeService();
	try {
		//request is sent
		GeocodeResponse response = serviceObj.geocode(reqObj);
		JAXBElement<ArrayOfGeocodeResult> results = response.getResults();
		//response is extracted
		ArrayOfGeocodeResult resultObj = results.getValue();
		List<GeocodeResult> geo = resultObj.getGeocodeResult();
		for(GeocodeResult obj : geo){
			JAXBElement<ArrayOfGeocodeLocation> locationResult = obj.getLocations();
			List<GeocodeLocation> geoLocation = locationResult.getValue().getGeocodeLocation();
			for(GeocodeLocation obj1: geoLocation ){
				coordinates.setLatitude(obj1.getLatitude());
				coordinates.setLongitude(obj1.getLongitude());
			}
		}
	} catch (IGeocodeServiceGeocodeResponseSummaryFaultFaultMessage e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return coordinates;
}
}
