@javax.xml.bind.annotation.XmlSchema(namespace = "http://dev.virtualearth.net/webservices/v1/geocode/contracts", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package net.virtualearth.dev.webservices.v1.geocode.contracts;
