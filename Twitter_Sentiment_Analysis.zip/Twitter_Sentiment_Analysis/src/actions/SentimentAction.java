package actions;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import classes.DandelionResponse;
import classes.Tweets;

public class SentimentAction {
	Client client ;
	WebTarget target; 
	DandelionResponse parsedResponse = null;
	public SentimentAction(){
		client = ClientBuilder.newClient();	//client object created
	}
	public List<Tweets> getSentiment(List<Tweets> tweetList){
		String encodedTweet = null;
		List<Tweets> responseList = new ArrayList<Tweets>();
		try {
		for(Tweets obj :tweetList){
			encodedTweet = URLEncoder.encode(obj.getTweet(), "UTF-8");//tweet is encoded to supprt url format
			//defining the target web service for the client object
			target = client.target("https://api.dandelion.eu/datatxt/sent/v1/?lang=en&text="+encodedTweet+"&token=c590b8bec54649b4acd6834ed83a2ee3");
			parsedResponse = parseResponseToJson(target.request().get(String.class));
			System.out.println(target.request().get(String.class));
			obj.setSentiment(parsedResponse);
			responseList.add(obj);
		}
		}catch(UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		//return target.request().get(String.class);
		return responseList;
	}
	
	public DandelionResponse parseResponseToJson(String response){
		Gson gsonObj = new Gson();
		parsedResponse = gsonObj.fromJson(response, DandelionResponse.class);
		return parsedResponse;
	}
}
