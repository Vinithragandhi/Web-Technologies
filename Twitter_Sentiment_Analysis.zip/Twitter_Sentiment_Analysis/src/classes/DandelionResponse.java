package classes;
public class DandelionResponse
{
    private int time;
    
    private SentimentScore sentiment;
    
    String lang;
    
    String timeStamp;

   // private SentimentScore type;

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public SentimentScore getScoreObj() {
		return sentiment;
	}

	public void setScoreObj(SentimentScore scoreObj) {
		this.sentiment = scoreObj;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
    
}