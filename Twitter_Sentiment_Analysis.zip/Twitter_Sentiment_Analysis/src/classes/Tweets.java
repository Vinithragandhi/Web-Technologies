package classes;

public class Tweets {

	
	public String tweet;
	public String username;
	public String location;
	public DandelionResponse sentiment;
	
	
	public String getTweet() {
		return tweet;
	}
	public void setTweet(String tweet) {
		this.tweet = tweet;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public DandelionResponse getSentiment() {
		return sentiment;
	}
	public void setSentiment(DandelionResponse sentiment) {
		this.sentiment = sentiment;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
}
